Name: Man Cao, Lilong Jiang
###################################################################
Work:
The code and document is written and edited by both students.

###################################################################
How to run the program:
1. Unpack the submitted files:

	tar xzf submission.tar.gz

2. Run the following command:

	python main.py

###################################################################
Directory structure:
README.txt: 		This file.
main.py:  		The source code of this project.
report.pdf:		The report for this project.
FreqVectors.txt:	The input file for the source code.

###################################################################
Output:
During runtime, it will print the precision, time for building the model and time for testing the model in each round of cross validation. It will take about 15min to run KNN classifier and 4min to run Baysian classifier.

